function A = mat_ex1(n,alpha,beta)
  %Matrice de l'exemple 1 du TD.
  S = eye(n)+diag(beta*ones(n-1,1),1);
  B = diag([1,1+alpha,[3:n]]);
  A = S*B*inv(S);
end