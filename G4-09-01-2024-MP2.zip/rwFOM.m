function [tab_x,tab_r,nb_red] = rwFOM(A,b,x0,m,epsilon,itmax)
  %Cette fonction applique la méthode FOM redémarrée et pondérée à un système linéaire Ax = b.
  n = length(A);
  r0 = b - A*x0;
  r0_ini = r0;
  nb_red = zeros(1,itmax);
  tab_x = zeros(n,itmax);
  tab_r = zeros(1,itmax);
  tab_r(1) = norm(r0);
  e = zeros(m,1);e(1) = 1;
  for i = 1:itmax
    nb_red(i) = i;
    d = (sqrt(n)*r0)/norm(r0_ini);
    sd = sqrt(d);
    sd_r0 = sd.*r0;
    beta = sqrt(sd_r0'*sd_r0);
    v1 = r0/beta;
    [V,H] = wArnoldi(A,v1,m,d);
    H = H(1:m,:);
    b1 = beta*e;
    [Q,R] = qr(H);
    y = R \ (Q'*b1);
    x = x0 + V(:,1:m)*y;
    tab_x(:,i) = x;
    tab_r(i+1) = norm(r0);
    r = b - A*x;
    if norm(r) <= epsilon
      tab_r = tab_r(1:i+1);
      nb_red = nb_red(1:i);
      tab_x = tab_x(:,1:i);
      break;
    else
      x0 = x;
      r0 = r;
    end
  end
end