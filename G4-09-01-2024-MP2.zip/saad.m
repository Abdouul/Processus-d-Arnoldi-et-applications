function A = saad(m, p, delta)
  %Génération de la matrice dont la symétrie varie selon la valeur de delta.
  B = zeros(p);
  diag_B = -4 * ones(p, 1);
  inf_B = (-1+delta) * ones(p-1, 1);
  sup_B = (-1-delta) * ones(p-1, 1);
  B = B + diag(diag_B) + diag(inf_B, -1) + diag(sup_B, 1);
  n = m*p;
  A  = zeros(n);
  I = eye(p);
  for i = 1:m
    A((i-1)*p+1:i*p, (i-1)*p+1:i*p) = B;
    if i < m
      A((i-1)*p+1:i*p, i*p+1:(i+1)*p) = -I;
    end
    if i > 1
      A((i-1)*p+1:i*p, (i-2)*p+1:(i-1)*p) = -I;
    end
  end
end