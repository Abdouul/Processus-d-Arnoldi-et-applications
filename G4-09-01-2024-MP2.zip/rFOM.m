function [tab_x,tab_r,nb_red] = rFOM(A,b,x0,m,epsilon,itmax)
  %Cette fonction applique la méthode FOM redémarrée au système A*x = b.
  n = length(A);
  r0 = b - A*x0;
  beta = norm(r0);
  nb_red = zeros(1,itmax);
  tab_x = zeros(n,itmax);
  tab_r = zeros(1,itmax);
  tab_r(1) = norm(r0);
  e = zeros(m,1);e(1) = 1;
  for i = 1:itmax
    nb_red(i) = i;
    [V,H] = Arnoldi(A,r0,m);
    H = H(1:m,:);
    b1 = beta*e;
    d = H \ b1;
    x = x0 + V(:,1:m)*d;
    tab_x(:,i) = x;
    tab_r(i+1) = norm(r0);
    r = b - A*x;
    if norm(r) <= epsilon
      tab_r = tab_r(1:i+1);
      nb_red = nb_red(1:i);
      tab_x = tab_x(:,1:i);
      break;
    else
      x0 = x;
      r0 = r;
      beta = norm(r0);
    end
  end
end