function A = mat_ex2(n,epsilon)
  %Matrice de l'exemple 2 du TD.
  A = diag(-1*ones(n-1,1),-1) + epsilon*eye(n) + diag(ones(n-1,1),1);
end