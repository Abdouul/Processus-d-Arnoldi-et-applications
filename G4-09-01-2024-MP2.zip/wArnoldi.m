function [V,H] = wArnoldi(A,v,m,d)
%Cette fonction permet d'implementer le processus d'Arnoldi pondéré.
sd = sqrt(d);
V(:,1) = v/sqrt((sd.*v)'*(sd.*v));
n = length(A);
H = zeros(m+1,m); 
for k = 1:m
    u = A*V(:,k);
    for j = 1:k
        H(j,k) = (sd.*u)'*(sd.*V(:,j));
        u = u - H(j,k)*V(:,j);
    end
    sd_u = sd.*u;
    H(k+1,k) = sqrt(sd_u'*sd_u);
    if H(k+1,k) == 0
      break;
    end
    V(:,k+1) = u/H(k+1,k);
end
end