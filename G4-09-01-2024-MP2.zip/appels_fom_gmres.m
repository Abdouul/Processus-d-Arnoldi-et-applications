%Le programme d'appel affiche, en fonction de la matrice choisie, un graphe montrant les comportements
%de convergence des différentes méthodes pour cette matrice. Il affiche aussi dans la console un
%tableau récapitulatif des résultats obtenus.

clear all
close all
clc

fprintf('=============================================================================\n');
fprintf('PROGRAMME DE TEST DES MÉTHODES rFOM,rGMRES,rwFOM,rwGMRES SUR DIVERS SYSTÈMES \n');
fprintf('=============================================================================\n');
fprintf('Ci-dessous sont affichées les matrices disponibles.\n');
fprintf('1 - Exemple 1\n2 - Exemple 2\n3 - Saad\n4 - bcsstk16\n5 - bcsstm22\n');
fprintf('6 - e40r5000\n7 - add20\n8 - orsirr_1\n9 - fs_541_2\n10 - bfw782a\n');
fprintf('11 - memplus\n12 - Poisson\n');
CHOIX = 1:12;
choix = input('Entrez un des chiffres pour poursuivre(une matrice sera choisie aléatoirement si vous appuyez sur ''Entrée''): ');
while choix < 1 || choix > 12 || not(isnumeric(choix))
  choix = input('Entrée incorrecte. Rééssayez: ');
end
if isempty(choix)
  choix = CHOIX(randi(length(CHOIX),1));
end
fprintf('\n1 - sparse\n2 - full\n');
stockage = input('Choisissez le type de stockage(le stockage ''full'' sera choisi par défaut si vous appuyez sur ''Entrée''): ');
while stockage < 1 || stockage > 2
  stockage = input('Entrée incorrecte. Rééssayez: ');
end
fprintf('\n');
m = input('Entrez m(une valeur par défaut sera choisie aléatoirement si vous appuyez sur ''Entrée''): ');
while m <= 0
  m = input('Entrée incorrecte. Rééssayez: ');
end
fprintf('\n1 - oui\n2 - non\n');
afficher_redemarrage = input('Voulez voir les points de redémarrage affichés sur les graphes (ils sont affichés par défaut si vous appuyez sur ''Entrée'') ? ');
fprintf('\n');
max_red = input('Quel est le nombre maximal de redémarrage (la valeur est 1000 par défaut si vous appuyez sur ''Entrée'') ? ');
fprintf('\n');
while max_red <= 0
      max_red = input('Entrée incorrecte. Rééssayez: ');
end
M = 5:5:80;
tol = 1.d-10;
if isempty(max_red)
  max_red = 1000;
end
switch choix
  case 1 %exemple 1
    n = input('Entrez n(une valeur par défaut sera choisie aléatoirement si vous appuyez sur ''Entrée''): ');
    while n <= 0
      n = input('Entrée incorrecte. Rééssayez: ');
    end
    matrice = 'Exemple 1';
    N = [200,500,1000];
    M = [10,20,50,100];
    BETA = [0.9,1.1];
    ALPHA = [1,0];    
    if isempty(n)
      n = N(randi(length(N),1));
    end
    if isempty(m)
      m = M(randi(length(M),1));
    end
    alpha = input('Entrez alpha(une valeur par défaut sera choisie aléatoirement si vous appuyez sur ''Entrée''): ');
    choix_auto_beta = 0;
    if isempty(alpha)
      i_choix_alpha = randi(length(ALPHA),1);
      alpha = ALPHA(i_choix_alpha);
      beta = BETA(i_choix_alpha);
      choix_auto_beta = 1;
    end
    if choix_auto_beta == 0
      beta = input('Entrez beta(une valeur par défaut sera choisie aléatoirement si vous appuyez sur ''Entrée''): ');
      if isempty(beta)
         i_choix_alpha = find(ALPHA == alpha);
         beta = BETA(i_choix_alpha);
      end
    end
    if stockage == 1
      A = sparse(mat_ex1(n,alpha,beta));
    else
      A = mat_ex1(n,alpha,beta);
    end
    fprintf('\nalpha = %f\tbeta = %f\n',alpha,beta);
  case 2 %exemple 2
    n = input('Entrez n(une valeur par défaut sera choisie aléatoirement si vous appuyez sur ''Entrée''): ');
    while n <= 0
      n = input('Entrée incorrecte. Rééssayez: ');
    end
    matrice = 'Exemple 2';
    N = [40,100];
    M = [10,20,50,100];
    EPSILON = [0.1,0.5,10];
    if isempty(n)
      n = N(randi(length(N),1));
    end
    if isempty(m)
      m = M(randi(length(M),1));
    end
    epsilon = input('Entrez epsilon(une valeur par défaut sera choisie aléatoirement si vous appuyez sur ''Entrée''): ');
    if isempty(epsilon)
      epsilon = EPSILON(randi(length(EPSILON),1));
    end
    if stockage == 1
      A = sparse(mat_ex2(n,epsilon));
    else
      A = mat_ex2(n,epsilon);
    end
    fprintf('\nepsilon = %f\n',epsilon);
  case 3 %saad
    matrice = 'Saad';
    P = [20,50,100];
    Q = P;
    DELTA = [0,0.5,10,10^4];
    M = [10,20,50,100];
    if isempty(m)
      m = M(randi(length(M),1));
    end
    p = input('Entrez p(une valeur par défaut sera choisie aléatoirement si vous appuyez sur ''Entrée''): ');
    if isempty(p)
      p = P(randi(length(P),1));
    end
    q = input('Entrez q(une valeur par défaut sera choisie aléatoirement si vous appuyez sur ''Entrée''): ');
    if isempty(q)
      q = Q(randi(length(Q),1));
    end
    delta = input('Entrez delta(une valeur par défaut sera choisie aléatoirement si vous appuyez sur ''Entrée''): ');
    if isempty(delta)
      delta = DELTA(randi(length(DELTA),1));
    end
    n = p*q;
    if stockage == 1
      A = sparse(saad(q,p,delta));
    else
      A = saad(q,p,delta);
    end
    fprintf('\ndelta = %f\n',delta);
  case 4 %bcsstk16
    matrice = 'bcsstk16';
    if isempty(m)
      m = M(randi(length(M),1));
    end
    [A,l,c] = mmread('bcsstk16.mtx');
    n = l;
    if stockage == 2
      A = full(A);
    end
    if isempty(stockage)
      A = full(A);
    end
  case 5 %bcsstm22
    matrice = 'bcsstm22';
    if isempty(m)
      m = M(randi(length(M),1));
    end
    [A,l,c] = mmread('bcsstm22.mtx');
    n = l;
    if stockage == 2
      A = full(A);
    end
    if isempty(stockage)
      A = full(A);
    end
  case 6 %e40r5000
    matrice = 'e40r5000';
    if isempty(m)
      m = M(randi(length(M),1));
    end
    [A,l,c] = mmread('e40r5000.mtx');
    n = l;
    if stockage == 2
      A = full(A);
    end
    if isempty(stockage)
      A = full(A);
    end
  case 7 %add20
    matrice = 'add20';
    tol = 1.d-12;
    if isempty(m)
      m = M(randi(length(M),1));
    end
    [A,l,c] = mmread('add20.mtx');
    n = l;
    if stockage == 2
      A = full(A);
    end
    if isempty(stockage)
      A = full(A);
    end
  case 8 %orsirr_1
    matrice = 'orsirr_1';
    tol = 1.d-11;
    if isempty(m)
      m = M(randi(length(M),1));
    end
    [A,l,c] = mmread('orsirr_1.mtx');
    n = l;
    if stockage == 2
      A = full(A);
    end
    if isempty(stockage)
      A = full(A);
    end
  case 9 %fs_541_2
    matrice = 'fs_541_2';
    if isempty(m)
      m = M(randi(length(M),1));
    end
    [A,l,c] = mmread('fs_541_2.mtx');
    n = l;
    if stockage == 2
      A = full(A);
    end
    if isempty(stockage)
      A = full(A);
    end
  case 10 %bfw782a
    matrice = 'bfw782a';
    tol = 1.d-12;
    if isempty(m)
      m = M(randi(length(M),1));
    end
    [A,l,c] = mmread('bfw782a.mtx');
    n = l;
    if stockage == 2
      A = full(A);
    end
    if isempty(stockage)
      A = full(A);
    end
  case 11 %memplus
    matrice = 'memplus';
    tol = 1.d-12;
    if isempty(m)
      m = M(randi(length(M),1));
    end
    [A,l,c] = mmread('memplus.mtx');
    n = l;
    if stockage == 2
      A = full(A);
    end
    if isempty(stockage)
      A = full(A);
    end
  case 12 %Poisson
    matrice = 'Poisson';
    if isempty(m)
      m = M(randi(length(M),1));
    end
    n = input('Entrez n(une valeur par défaut sera choisie aléatoirement si vous appuyez sur ''Entrée''): ');
    while n <= 0
      n = input('Entrée incorrecte. Rééssayez: ');
    end
    if isempty(n)
      n = m;
    end
    A = gallery('poisson',n);
    n = n^2;
    if stockage == 2
      A = full(A);
    end
    if isempty(stockage)
      A = full(A);
    end
  otherwise 
    fprintf('Une erreur a été rencontrée durant le processus.');
end

%Construction du système
sol_e = (1:n)';
b = A*sol_e;
x0 = zeros(n,1);

%Appels des méthodes
tic;
[xFOM,res_FOM,nb_red_FOM] = rFOM(A,b,x0,m,tol,max_red);
t_CPU_FOM = toc;
tic;
[xGMRES,res_GMRES,nb_red_GMRES] = rGMRES(A,b,x0,m,tol,max_red);
t_CPU_GMRES = toc;
tic;
[xwFOM,res_wFOM,nb_red_wFOM] = rwFOM(A,b,x0,m,tol,max_red);
t_CPU_wFOM = toc;
tic;
[xwGMRES,res_wGMRES,nb_red_wGMRES] = rwGMRES(A,b,x0,m,tol,max_red);
t_CPU_wGMRES = toc;

% Comparaison des résultats dans un tableau
resultats = table({'rFOM'; 'rGMRES'; 'rwFOM'; 'rwGMRES'}, ...
                  [nb_red_FOM(end); nb_red_GMRES(end); nb_red_wFOM(end); nb_red_wGMRES(end)], ...
                  [res_FOM(end); res_GMRES(end); res_wFOM(end); res_wGMRES(end)], ...
                  [norm(xFOM(:,end)-sol_e); norm(xGMRES(:,end)-sol_e); norm(xwFOM(:,end)-sol_e); norm(xwGMRES(:,end)-sol_e)], ...
                  [t_CPU_FOM; t_CPU_GMRES; t_CPU_wFOM; t_CPU_wGMRES], ...
                  'VariableNames', {'Méthode', 'Iterations', 'ResiduFinal', 'Erreur', 'TempsCPU'});

% Affichage du tableau dans le format demandé
disp('Tableau de comparaison des méthodes :');
fprintf('--------------------------------------------------------\n')
fprintf('%10s %10s %10s %10s %10s\n', 'Méthode', 'rfom', 'rgmres', 'rwfom', 'rwgmres');
fprintf('--------------------------------------------------------\n')
fprintf('%10s %10d %10d %10d %10d\n', 'Itérations', resultats.Iterations);
fprintf('%10s %10.2e %10.2e %10.2e %10.2e\n', 'RésiduFinal', resultats.ResiduFinal);
fprintf('%10s %10.2e %10.2e %10.2e %10.2e\n', 'Erreur', resultats.Erreur);
fprintf('%10s %10.2e %10.2e %10.2e %10.2e\n', 'TempsCPU', resultats.TempsCPU);
fprintf('--------------------------------------------------------\n')

%Courbes
axe_x_FOM = 0:nb_red_FOM(end);
axe_x_GMRES = 0:nb_red_GMRES(end);
axe_x_wFOM = 0:nb_red_wFOM(end);
axe_x_wGMRES = 0:nb_red_wGMRES(end);
figure(1);
if afficher_redemarrage == 2
  plot(axe_x_FOM,log10(res_FOM),'-r');
  hold on;
  plot(axe_x_GMRES,log10(res_GMRES),'-k');
  hold on;
  plot(axe_x_wFOM,log10(res_wFOM),'-ob');
  hold on;
  plot(axe_x_wGMRES,log10(res_wGMRES),'--*m');
  hold off;
  grid on;
  xlabel('Nombre d''itérations')
  ylabel('Norme du résidu (log10)')
  legend('rFOM','rGMRES','rwFOM','rwGMRES');
  title(strcat('Matrice',{' '},matrice,{' '},'(n=',num2str(n),{' '},'m=',num2str(m),')'));
else
  p = zeros(1,8);
  p(1) = plot(axe_x_FOM,log10(res_FOM),'-r');
  hold on;
  p(2) = plot(axe_x_FOM(1:length(axe_x_FOM)),log10(res_FOM(1:length(res_FOM))),'+k');
  hold on;
  p(3) = plot(axe_x_GMRES,log10(res_GMRES),'-g');
  hold on;
  p(4) = plot(axe_x_GMRES(1:length(axe_x_GMRES)),log10(res_GMRES(1:length(res_GMRES))),'+k');
  hold on;
  p(5) = plot(axe_x_wFOM,log10(res_wFOM),'-ob');
  hold on;
  p(6) = plot(axe_x_wFOM(1:length(axe_x_wFOM)),log10(res_wFOM(1:length(res_wFOM))),'+k');
  hold on;
  p(7) = plot(axe_x_wGMRES,log10(res_wGMRES),'--*m');
  hold on;
  p(8) = plot(axe_x_wGMRES(1:length(axe_x_wGMRES)),log10(res_wGMRES(1:length(res_wGMRES))),'+k');
  hold off;
  grid on;
  xlabel('Nombre d''itérations')
  ylabel('Norme du résidu (log10)')
  legend([p(1:2:8)],'rFOM','rGMRES','rwFOM','rwGMRES');
  title(strcat('Matrice',{' '},matrice,{' '},'(n=',num2str(n),{' '},'m=',num2str(m),')'));
end